Game made by Joseph Saponaro
6/29/2024

How To Play:

Click crops, then click the plot of land to plant them.

Click the plot again to sell the crop. Each crop sells for more than its cost. Once the player reaches-
200 gold. They can unlock the farm area containing pigs. This is a clicker type level where the player-
can click as many times as they want to spawn more pigs in the pen. They can then sell the pigs to make-
x number of gold. This level was designed with old "cool math" style games in mind and does not require any-
skill beyond basic arithmetic. It is meant to be played mostly by children but is suited for anyone.

Enjoy!

-Joseph Saponaro